T = int(input())

for i in range(1,T+1):
    N, M, K = map(int, input().split())
    # str로 받자, * 섞임
    arr = [list(input()) for _ in range(N)]

    """
    mxm 크기의 영역만 탐색 가능, 정확히 k개의 별을 포함하는 mxm영역 찾기
    조건 만족 영역은 한개이하 -> 하나만 찾기, 없을 수도 있다 !!
    조건에 맞는 영역이 없는 경우, -1, -1
    """
    def run_scouter(y,x):
        temp_cnt = 0
        for i in range(M):
            for j in range(M):
                if arr[y+i][x+j] == '*':
                    temp_cnt +=1
        if temp_cnt == K:
            return True
        else:
            return False

    # 조건에 맞는 경우 없을 수도 있다
    # ex n 6 m =3 0 0 -> 6-3 +1
    # 기본값 -1,-1해서 아예 조건 없으면 그대로 -1 -1 출력
    cy = -1
    cx = -1
    for j in range((N+1)-M):
        for k in range((N+1)-M):
            if run_scouter(j,k):
                cy = j
                cx = k
                break

    print(f"#{i} {cy} {cx}")
