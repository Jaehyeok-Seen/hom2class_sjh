T = int(input())

def check_safe(y, x):
    center = arr[y][x]
    if center > arr[y-1][x] and center > arr[y+1][x] and center > arr[y][x-1] and center > arr[y][x+1]:
        return True
    else:
        return False

for i in range(1, T+1):
    N, M = map(int, input().split())
    arr = [list(map(int, input().split())) for _ in range(N)]
    """
    모든 인접구역보다도 높은 지역은 안전 구역
    상, 하, 좌, 우 보다 큰 지점 (상, 하, 좌, 우 모두 조건)
    가장 가장자리 구역은 제외
    예외 케이스 딱히 존재 x
    """
    total_safe = 0
    for j in range(1,N-1):
        for k in range(1,M-1):
            if check_safe(j, k):
                total_safe+=1
    print(f"#{i} {total_safe}")